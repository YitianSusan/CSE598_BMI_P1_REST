﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace BMIRESTService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public double myBMI(int height, int weight)
        {
            return getBMI(height, weight);
        }

        public BMI myHealth(int height, int weight)
        {
            double bmi_score = getBMI(height, weight);
            string risk = getRisk(bmi_score);

            BMI result = new BMI();
            result.bmiScore = bmi_score;
            result.RiskValue = risk;
            return result;
        }


        private string getRisk(double bmi_score)
        {
            if (bmi_score < 18)
            {
                return "underweight - Blue";
            }
            else if (bmi_score < 25)
            {
                return "normal - Green";
            }
            else if (bmi_score < 30)
            {
                return "pre-obese - Purple";
            }
            else
            {
                return "obese - Red";
            }
        }

        private double getBMI(int height, int weight)
        {
            return ((double)weight / (double)height / (double)height) * 730;
        }
    }
}
