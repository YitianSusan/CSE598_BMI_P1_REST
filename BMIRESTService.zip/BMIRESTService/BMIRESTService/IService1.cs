﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace BMIRESTService
{
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        [WebGet(UriTemplate = "/myBMI?height={height}&weight={weight}", ResponseFormat = WebMessageFormat.Json)]
        double myBMI(int height, int weight);

        [OperationContract]
        [WebGet(UriTemplate = "/myHealth?height={height}&weight={weight}", ResponseFormat = WebMessageFormat.Json)]
        BMI myHealth(int height, int weight);
    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class BMI
    {
        double bmi;
        string risk;
        string[] more = new string[] {"https://www.cdc.gov/healthyweight/assessing/bmi/index.html",
            "https://www.nhlbi.nih.gov/health/educational/lose_wt/index.htm",
            "https://www.ucsfhealth.org/education/body_mass_index_tool/"};

        [DataMember]
        public double bmiScore
        {
            get { return bmi; }
            set { bmi = value; }
        }

        [DataMember]
        public string RiskValue
        {
            get { return risk; }
            set { risk = value; }
        }

        [DataMember]
        public string[] More
        {
            get { return more; }
        }



    }
    
        
}
